import { useState, useRef } from "react";

const ROLES = [
  { id: "web_developer", label: "Web Developer", icon: "⚡", color: "#00d4ff" },
  { id: "data_scientist", label: "Data Scientist", icon: "🧠", color: "#a78bfa" },
  { id: "content_writer", label: "Content Writer", icon: "✍️", color: "#fb923c" },
  { id: "devops_engineer", label: "DevOps Engineer", icon: "🔧", color: "#34d399" },
  { id: "ml_engineer", label: "ML Engineer", icon: "🤖", color: "#f472b6" },
  { id: "ui_ux_designer", label: "UI/UX Designer", icon: "🎨", color: "#fbbf24" },
  { id: "backend_developer", label: "Backend Developer", icon: "🗄️", color: "#60a5fa" },
  { id: "product_manager", label: "Product Manager", icon: "📊", color: "#4ade80" },
];

const SYSTEM_PROMPT = `You are an expert resume analyzer and career coach with deep knowledge of industry standards.
Analyze the given resume text for the specified role and return ONLY a valid JSON object with this exact structure:
{
  "overallScore": <number 0-100>,
  "summary": "<2-3 sentence overall assessment>",
  "keywordsFound": ["keyword1", "keyword2", ...],
  "keywordsMissing": ["keyword1", "keyword2", ...],
  "sections": {
    "skills": { "score": <0-100>, "feedback": "<specific feedback>" },
    "experience": { "score": <0-100>, "feedback": "<specific feedback>" },
    "education": { "score": <0-100>, "feedback": "<specific feedback>" },
    "projects": { "score": <0-100>, "feedback": "<specific feedback>" },
    "formatting": { "score": <0-100>, "feedback": "<specific feedback>" }
  },
  "strengths": ["strength1", "strength2", "strength3"],
  "improvements": ["improvement1", "improvement2", "improvement3"],
  "atsScore": <number 0-100>,
  "verdict": "<one of: Excellent, Good, Average, Needs Work>"
}
Return ONLY the JSON. No markdown, no explanation, no backticks.`;

export default function ResumeAnalyzer() {
  const [resumeText, setResumeText] = useState("");
  const [selectedRole, setSelectedRole] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState(1);
  const fileRef = useRef();

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.type === "text/plain") {
      const reader = new FileReader();
      reader.onload = (ev) => setResumeText(ev.target.result);
      reader.readAsText(file);
    } else {
      setError("Please upload a .txt file or paste your resume text below.");
    }
  };

  const analyze = async () => {
    if (!resumeText.trim()) { setError("Resume text is empty."); return; }
    if (!selectedRole) { setError("Please select a role."); return; }
    setError("");
    setLoading(true);

    try {
      const role = ROLES.find(r => r.id === selectedRole);
      const prompt = `Analyze this resume for the role of "${role.label}":\n\n${resumeText}`;

      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1500,
          system: SYSTEM_PROMPT,
          messages: [{ role: "user", content: prompt }],
        }),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error?.message || `API error ${res.status}`);
      }

      const raw = data.content?.map(i => i.text || "").join("").trim();
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setResult(parsed);
      setStep(2);
    } catch (err) {
      setError(`Analysis failed: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const reset = () => { setResult(null); setStep(1); setResumeText(""); setSelectedRole(null); setError(""); };

  const scoreColor = (s) => s >= 80 ? "#4ade80" : s >= 60 ? "#fbbf24" : s >= 40 ? "#fb923c" : "#f87171";
  const verdictColor = { "Excellent": "#4ade80", "Good": "#60a5fa", "Average": "#fbbf24", "Needs Work": "#f87171" };

  const CircleScore = ({ score, size = 80 }) => {
    const r = (size / 2) - 8;
    const circ = 2 * Math.PI * r;
    const dash = (score / 100) * circ;
    const color = scoreColor(score);
    return (
      <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
        <svg width={size} height={size} style={{ transform: "rotate(-90deg)", position: "absolute" }}>
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="6" />
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="6"
            strokeDasharray={`${dash} ${circ}`} strokeLinecap="round" />
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontSize: size > 70 ? 20 : 14, fontWeight: 800, color, fontFamily: "'Space Mono', monospace" }}>{score}</span>
        </div>
      </div>
    );
  };

  const ScoreBar = ({ score, label, feedback }) => (
    <div style={{ marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
        <span style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>{label}</span>
        <span style={{ fontSize: 13, fontWeight: 700, color: scoreColor(score), fontFamily: "'Space Mono', monospace" }}>{score}/100</span>
      </div>
      <div style={{ background: "rgba(255,255,255,0.07)", borderRadius: 6, height: 8, overflow: "hidden" }}>
        <div style={{ width: `${score}%`, height: "100%", background: scoreColor(score), borderRadius: 6 }} />
      </div>
      {feedback && <p style={{ margin: "6px 0 0", fontSize: 12, color: "rgba(255,255,255,0.45)", lineHeight: 1.5 }}>{feedback}</p>}
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", fontFamily: "'DM Sans', sans-serif", color: "#fff", padding: 0, position: "relative", overflow: "hidden" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />

      {/* Ambient BG */}
      <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", top: "-20%", left: "-10%", width: "60vw", height: "60vw", background: "radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%)", borderRadius: "50%" }} />
        <div style={{ position: "absolute", bottom: "-20%", right: "-10%", width: "50vw", height: "50vw", background: "radial-gradient(circle, rgba(168,85,247,0.1) 0%, transparent 70%)", borderRadius: "50%" }} />
      </div>

      <div style={{ position: "relative", zIndex: 1, maxWidth: 760, margin: "0 auto", padding: "40px 20px" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.3)", borderRadius: 24, padding: "6px 16px", marginBottom: 20, fontSize: 13, color: "#a5b4fc" }}>
            <span style={{ width: 8, height: 8, background: "#6366f1", borderRadius: "50%", display: "inline-block", boxShadow: "0 0 8px #6366f1" }} />
            AI-Powered Resume Analysis
          </div>
          <h1 style={{ fontSize: "clamp(28px, 5vw, 44px)", fontWeight: 800, margin: 0, letterSpacing: "-1px", fontFamily: "'Space Mono', monospace" }}>
            Resume<span style={{ color: "#6366f1" }}>.</span>AI
          </h1>
          <p style={{ color: "rgba(255,255,255,0.4)", margin: "10px 0 0", fontSize: 15 }}>
            Paste your resume → pick a role → get instant AI feedback
          </p>
        </div>

        {step === 1 && (
          <div style={{ display: "flex", flexDirection: "column", gap: 28 }}>
            {/* Upload / Paste */}
            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)", borderRadius: 16, padding: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>📄 Resume Text</h2>
                <button onClick={() => fileRef.current.click()} style={{ background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.4)", borderRadius: 8, padding: "6px 14px", color: "#a5b4fc", cursor: "pointer", fontSize: 13 }}>
                  Upload .txt
                </button>
              </div>
              <input ref={fileRef} type="file" accept=".txt" onChange={handleFile} style={{ display: "none" }} />
              <textarea
                value={resumeText}
                onChange={e => setResumeText(e.target.value)}
                placeholder="Paste your resume here... (name, skills, experience, education, projects)"
                style={{ width: "100%", minHeight: 200, background: "rgba(0,0,0,0.3)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, padding: 16, color: "#fff", fontSize: 14, resize: "vertical", fontFamily: "'DM Sans', sans-serif", lineHeight: 1.6, boxSizing: "border-box", outline: "none" }}
              />
              <p style={{ margin: "8px 0 0", fontSize: 12, color: "rgba(255,255,255,0.3)" }}>
                {resumeText.length} characters · Tip: More detail = better analysis
              </p>
            </div>

            {/* Role Selection */}
            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)", borderRadius: 16, padding: 24 }}>
              <h2 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700 }}>🎯 Target Role</h2>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 10 }}>
                {ROLES.map(role => (
                  <button key={role.id} onClick={() => setSelectedRole(role.id)} style={{ background: selectedRole === role.id ? `${role.color}18` : "rgba(255,255,255,0.03)", border: `1px solid ${selectedRole === role.id ? role.color + "66" : "rgba(255,255,255,0.08)"}`, borderRadius: 12, padding: "12px 14px", cursor: "pointer", textAlign: "left", color: selectedRole === role.id ? role.color : "rgba(255,255,255,0.6)" }}>
                    <div style={{ fontSize: 22, marginBottom: 6 }}>{role.icon}</div>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{role.label}</div>
                  </button>
                ))}
              </div>
            </div>

            {error && <div style={{ background: "rgba(248,113,113,0.1)", border: "1px solid rgba(248,113,113,0.3)", borderRadius: 10, padding: "12px 16px", color: "#fca5a5", fontSize: 14 }}>{error}</div>}

            <button onClick={analyze} disabled={loading} style={{ background: loading ? "rgba(99,102,241,0.3)" : "linear-gradient(135deg, #6366f1, #8b5cf6)", border: "none", borderRadius: 12, padding: "16px 32px", color: "#fff", fontSize: 16, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", fontFamily: "'Space Mono', monospace", letterSpacing: "0.5px", boxShadow: loading ? "none" : "0 4px 24px rgba(99,102,241,0.35)" }}>
              {loading ? "🔍 Analyzing Resume..." : "⚡ Analyze Resume"}
            </button>
          </div>
        )}

        {step === 2 && result && (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

            {/* Verdict Banner */}
            <div style={{ background: `linear-gradient(135deg, ${verdictColor[result.verdict]}18, transparent)`, border: `1px solid ${verdictColor[result.verdict]}44`, borderRadius: 16, padding: 24, display: "flex", alignItems: "center", gap: 24, flexWrap: "wrap" }}>
              <CircleScore score={result.overallScore} size={90} />
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 22, fontWeight: 800, fontFamily: "'Space Mono', monospace", color: verdictColor[result.verdict] }}>{result.verdict}</span>
                  <span style={{ background: `${verdictColor[result.verdict]}22`, border: `1px solid ${verdictColor[result.verdict]}44`, borderRadius: 6, padding: "2px 10px", fontSize: 12, color: verdictColor[result.verdict] }}>
                    ATS Score: {result.atsScore}/100
                  </span>
                </div>
                <p style={{ margin: 0, color: "rgba(255,255,255,0.6)", fontSize: 14, lineHeight: 1.6 }}>{result.summary}</p>
              </div>
            </div>

            {/* Section Scores */}
            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)", borderRadius: 16, padding: 24 }}>
              <h3 style={{ margin: "0 0 20px", fontSize: 15, fontWeight: 700, color: "rgba(255,255,255,0.8)" }}>📊 Section Breakdown</h3>
              {Object.entries(result.sections).map(([key, val]) => (
                <ScoreBar key={key} score={val.score} label={key.charAt(0).toUpperCase() + key.slice(1)} feedback={val.feedback} />
              ))}
            </div>

            {/* Keywords */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div style={{ background: "rgba(74,222,128,0.05)", border: "1px solid rgba(74,222,128,0.2)", borderRadius: 16, padding: 20 }}>
                <h3 style={{ margin: "0 0 12px", fontSize: 14, fontWeight: 700, color: "#4ade80" }}>✅ Keywords Found</h3>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {result.keywordsFound?.map(k => (
                    <span key={k} style={{ background: "rgba(74,222,128,0.12)", border: "1px solid rgba(74,222,128,0.25)", borderRadius: 6, padding: "3px 10px", fontSize: 12, color: "#86efac" }}>{k}</span>
                  ))}
                </div>
              </div>
              <div style={{ background: "rgba(248,113,113,0.05)", border: "1px solid rgba(248,113,113,0.2)", borderRadius: 16, padding: 20 }}>
                <h3 style={{ margin: "0 0 12px", fontSize: 14, fontWeight: 700, color: "#f87171" }}>❌ Keywords Missing</h3>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {result.keywordsMissing?.map(k => (
                    <span key={k} style={{ background: "rgba(248,113,113,0.1)", border: "1px solid rgba(248,113,113,0.25)", borderRadius: 6, padding: "3px 10px", fontSize: 12, color: "#fca5a5" }}>{k}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Strengths & Improvements */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)", borderRadius: 16, padding: 20 }}>
                <h3 style={{ margin: "0 0 14px", fontSize: 14, fontWeight: 700, color: "#60a5fa" }}>💪 Strengths</h3>
                {result.strengths?.map((s, i) => (
                  <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10, alignItems: "flex-start" }}>
                    <span style={{ color: "#4ade80", marginTop: 1 }}>→</span>
                    <span style={{ fontSize: 13, color: "rgba(255,255,255,0.65)", lineHeight: 1.5 }}>{s}</span>
                  </div>
                ))}
              </div>
              <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)", borderRadius: 16, padding: 20 }}>
                <h3 style={{ margin: "0 0 14px", fontSize: 14, fontWeight: 700, color: "#fb923c" }}>🔨 Improvements</h3>
                {result.improvements?.map((s, i) => (
                  <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10, alignItems: "flex-start" }}>
                    <span style={{ color: "#f87171", marginTop: 1 }}>→</span>
                    <span style={{ fontSize: 13, color: "rgba(255,255,255,0.65)", lineHeight: 1.5 }}>{s}</span>
                  </div>
                ))}
              </div>
            </div>

            <button onClick={reset} style={{ background: "transparent", border: "1px solid rgba(255,255,255,0.15)", borderRadius: 12, padding: "12px 24px", color: "rgba(255,255,255,0.6)", cursor: "pointer", fontSize: 14 }}>
              ← Analyze Another Resume
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
